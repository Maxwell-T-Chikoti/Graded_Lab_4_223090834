import React, { useContext } from 'react';
import { SafeAreaView, ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import styled from 'styled-components/native';
import { FormContext } from './FormContext';

const Form1Screen = () => {
  const { formData, updateFormData } = useContext(FormContext);
  const navigation = useNavigation();

  const handleNext = () => {
    if (formData.name && formData.email && formData.phone) {
      navigation.navigate('Form2');
    } else {
      alert('Please fill in all fields');
    }
  };

  return (
    <SafeAreaView style={{ flex: 1 }}>
    <ScrollView>
        <Container>
          <Title>Sign Up</Title>
          <Subtitle>Fill in your details to get started</Subtitle>

          <Input 
            placeholder="Enter your name" 
            value={formData.name} 
            onChangeText={(text) => updateFormData('name', text)} 
            placeholderTextColor="#888"
          />
          <Input 
            placeholder="Enter your email" 
            value={formData.email} 
            onChangeText={(text) => updateFormData('email', text)} 
            placeholderTextColor="#888"
            keyboardType="email-address"
          />
          <Input 
            placeholder="Enter your phone number" 
            value={formData.phone} 
            onChangeText={(text) => updateFormData('phone', text)} 
            placeholderTextColor="#888"
            keyboardType="phone-pad"
          />

          <NextButton onPress={handleNext}>
            <ButtonText>Next</ButtonText>
          </NextButton>
        </Container>
        </ScrollView>
    </SafeAreaView>
  );
};

const Container = styled.View`
  flex: 1;
  padding: 20px;
  justify-content: center;
  background-color: #f7f8fa;
`;

const Title = styled.Text`
  font-size: 32px;
  font-weight: bold;
  color: #333;
  margin-bottom: 10px;
  text-align: center;
`;

const Subtitle = styled.Text`
  font-size: 18px;
  color: #666;
  margin-bottom: 30px;
  text-align: center;
`;

const Input = styled.TextInput`
  border-radius: 8px;
  border: 1px solid #ddd;
  background-color: #fff;
  margin-bottom: 20px;
  padding: 15px;
  font-size: 18px;
  color: #333;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
`;

const NextButton = styled.TouchableOpacity`
  background-color: #4CAF50;
  padding: 15px;
  border-radius: 8px;
  align-items: center;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
`;

const ButtonText = styled.Text`
  font-size: 18px;
  color: #fff;
  font-weight: bold;
`;

export default Form1Screen;
