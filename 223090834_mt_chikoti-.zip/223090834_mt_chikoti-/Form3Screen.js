import React, { useContext } from 'react';
import { SafeAreaView, ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import styled from 'styled-components/native';
import { FormContext } from './FormContext';

const Form3Screen = () => {
  const { formData, updateFormData, setFormCompleted } = useContext(FormContext);
  const navigation = useNavigation();

  const handleSubmit = () => {
    if (formData.creditCard && formData.expiration && formData.cvv) {
      setFormCompleted(true); // Now this should work
      alert('Form submitted successfully!');
      navigation.navigate('Menu'); // Navigate to MenuScreen
    } else {
      alert('Please fill in all fields');
    }
  };

  return (
    <SafeAreaView style={{ flex: 1 }}>
    <ScrollView>
      <Container>
          <Title>Payment Details</Title>
          <Subtitle>Fill in your payment information</Subtitle>

          <Input 
            placeholder="Enter your credit card number" 
            keyboardType="numeric" 
            value={formData.creditCard} 
            onChangeText={(text) => updateFormData('creditCard', text)} 
            placeholderTextColor="#888"
          />
          <Input 
            placeholder="Expiration Date (MM/YY)" 
            value={formData.expiration} 
            onChangeText={(text) => updateFormData('expiration', text)} 
            placeholderTextColor="#888"
          />
          <Input 
            placeholder="CVV" 
            keyboardType="numeric" 
            secureTextEntry 
            value={formData.cvv} 
            onChangeText={(text) => updateFormData('cvv', text)} 
            placeholderTextColor="#888"
          />

          <SubmitButton onPress={handleSubmit}>
            <ButtonText>Submit</ButtonText>
          </SubmitButton>
        </Container>
      </ScrollView>
    </SafeAreaView>
  );
};

// Styling components (same as before)
const Container = styled.View`
  flex: 1;
  padding: 20px;
  justify-content: center;
  background-color: #f7f8fa;
`;

const Title = styled.Text`
  font-size: 32px;
  font-weight: bold;
  color: #333;
  margin-bottom: 10px;
  text-align: center;
`;

const Subtitle = styled.Text`
  font-size: 18px;
  color: #666;
  margin-bottom: 30px;
  text-align: center;
`;

const Input = styled.TextInput`
  border-radius: 8px;
  border: 1px solid #ddd;
  background-color: #fff;
  margin-bottom: 20px;
  padding: 15px;
  font-size: 18px;
  color: #333;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
`;

const SubmitButton = styled.TouchableOpacity`
  background-color: #4CAF50;
  padding: 15px;
  border-radius: 8px;
  align-items: center;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
`;

const ButtonText = styled.Text`
  font-size: 18px;
  color: #fff;
  font-weight: bold;
`;

export default Form3Screen;
