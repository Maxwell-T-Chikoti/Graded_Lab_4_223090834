import React, { useContext } from 'react';
import { SafeAreaView } from 'react-native';
import { FormContext } from './FormContext';
import { ThemeContext } from './ThemeContext';
import styled from 'styled-components/native';

const ProfileScreen = () => {
  const { formData } = useContext(FormContext);
  const { theme, updateTheme } = useContext(ThemeContext);

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <Container style={{ backgroundColor: theme.backgroundColor }}>
        <Title style={{ color: theme.textColor }}>Profile Information</Title>
        <ProfileText style={{ color: theme.textColor }}>Name: {formData.name}</ProfileText>
        <ProfileText style={{ color: theme.textColor }}>Email: {formData.email}</ProfileText>
        <ProfileText style={{ color: theme.textColor }}>Phone: {formData.phone}</ProfileText>

        <ChangeButton onPress={() => updateTheme({ ...theme, textColor: '#ff0000' })}>
          <ButtonText>Change Text Color</ButtonText>
        </ChangeButton>

        <ChangeButton onPress={() => updateTheme({ ...theme, backgroundColor: '#000000' })}>
          <ButtonText>Change Background Color</ButtonText>
        </ChangeButton>
      </Container>
    </SafeAreaView>
  );
};

const Container = styled.View`
  flex: 1;
  padding: 20px;
  justify-content: center;
  background-color: #f7f8fa;
`;

const Title = styled.Text`
  font-size: 32px;
  font-weight: bold;
  color: #333;
  margin-bottom: 20px;
  text-align: center;
`;

const ProfileText = styled.Text`
  font-size: 18px;
  margin-bottom: 15px;
  color: #333;
`;

const ChangeButton = styled.TouchableOpacity`
  background-color: #4CAF50;
  padding: 15px;
  border-radius: 8px;
  align-items: center;
  margin-top: 10px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
`;

const ButtonText = styled.Text`
  font-size: 18px;
  color: #fff;
  font-weight: bold;
`;

export default ProfileScreen;
