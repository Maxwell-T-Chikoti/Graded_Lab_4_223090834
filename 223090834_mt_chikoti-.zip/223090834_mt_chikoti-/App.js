import React, { useContext } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { CartProvider } from './CartContext';
import { FormProvider, FormContext } from './FormContext';
import { ThemeProvider } from './ThemeContext';
import Ionicons from '@expo/vector-icons/Ionicons';
import AntDesign from '@expo/vector-icons/AntDesign';




import MenuScreen from './MenuScreen';
import CartScreen from './CartScreen';
import ProfileScreen from './ProfileScreen';
import Form1Screen from './Form1Screen';
import Form2Screen from './Form2Screen';
import Form3Screen from './Form3Screen';


const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

const FormStack = () => (
  <Stack.Navigator>
    <Stack.Screen name="Form1" component={Form1Screen} options={{ headerShown: false }} />
    <Stack.Screen name="Form2" component={Form2Screen} options={{ headerShown: false }} />
    <Stack.Screen name="Form3" component={Form3Screen} options={{ headerShown: false }} />
  </Stack.Navigator>
);

const MainTabs = () => (
  <Tab.Navigator initialRouteName="Menu">
    <Tab.Screen 
      name="Menu" 
      component={MenuScreen} 
      options={{ 
        headerShown: false,
        tabBarIcon: ({ color, size }) => (
          <Ionicons name="restaurant" size={24} color="green" />
        ),
      }} 
    />
    <Tab.Screen 
      name="Cart" 
      component={CartScreen} 
      options={{ 
        headerShown: false,
        tabBarIcon: ({ color, size }) => (
          <AntDesign name="shoppingcart" size={24} color="green" />
        ),
      }} 
    />
    <Tab.Screen 
      name="Profile" 
      component={ProfileScreen} 
      options={{ 
        headerShown: false,
        tabBarIcon: ({ color, size }) => (
          <AntDesign name="user" size={24} color="green" />
        ),
      }} 
    />
  </Tab.Navigator>
);

const AppStack = () => {
  const { formCompleted } = useContext(FormContext);

  return (
    <Stack.Navigator>
      {formCompleted ? (
        <Stack.Screen 
          name="MainTabs" 
          component={MainTabs} 
          options={{ headerShown: false }} 
          initialParams={{ screen: 'Menu' }}
        />
      ) : (
        <Stack.Screen 
          name="FormStack" 
          component={FormStack} 
          options={{ headerShown: false }} 
        />
      )}
    </Stack.Navigator>
  );
};

const App = () => {
  return (
    <CartProvider>
      <FormProvider>
        <ThemeProvider>
          <NavigationContainer>
            <AppStack />
          </NavigationContainer>
        </ThemeProvider>
      </FormProvider>
    </CartProvider>
  );
};

export default App;
